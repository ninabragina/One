let let1 : Int = 32

let let2 : String = "cat"

var var1 = 15

var var2 = "dog"

var var3 = 2.2

var c = var1 + Int(var3)

typealias someType = Int

var var4 : someType = 6

var1 += var1

var4 -= 3

var boolVar = false

if boolVar == true {
    print("one")
} else {
    print("two")
}

var2 += let2

for c in var2 {
    print(c)
}

var c1 : Character = "i"

var2 += String(c1)



